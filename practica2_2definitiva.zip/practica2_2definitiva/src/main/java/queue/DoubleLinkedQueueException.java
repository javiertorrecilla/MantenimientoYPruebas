package queue;

//realizado por Javier Torrecilla Reyes y Sandra Vazquez Perez

public class DoubleLinkedQueueException extends RuntimeException {
    public DoubleLinkedQueueException(String message) {
        super(message);
    }
}
