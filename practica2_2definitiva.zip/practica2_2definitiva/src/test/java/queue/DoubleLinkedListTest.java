package queue;

//realizado por Javier Torrecilla Reyes y Sandra Vazquez Perez

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Comparator;

public class DoubleLinkedListTest<T> {

    private DoubleLinkedList<Object> node;

    @Test 
    @DisplayName("Es instanciado con una doble lista enlazada")
    public void isInstantiatedWithNew(){
        new DoubleLinkedListTest<>();
    }

    @BeforeEach
    public void createNewList(){
        node = new DoubleLinkedList<>();
    }

    @Nested 
    @DisplayName("Test metodo prepend")
    class prependTest{
        @Test
        @DisplayName("Comprueba que con la lista vacia, al añadir delante el primer nodo, el primero y el ultimo es el ultimo")
        public void prepend_EmptyList_FirstEqualsLast(){
            Object valor = new Object();
            node.prepend(valor);
            
            Object expectedValue1 = node.first();
            Object expectedValue2 = node.last();

            assertEquals(valor, expectedValue1);
            assertEquals(expectedValue1, expectedValue2);
        }

        @Test
        @DisplayName("Comprueba que si añadimos por delante dos nodos, el ultimo añadido sera el primero y el primero sera el ultimo")
        public void prepend_TwoNodes_LastIsFirst(){
            Object valor1 = new Object();
            node.prepend(valor1);
            Object valor2 = new Object();
            node.prepend(valor2);
            
            Object expectedValueFirst = valor2;
            Object returnValueFirst = node.first();
            Object expectedValueLast = valor1;
            Object returnValueLast = node.last();

            assertEquals(expectedValueFirst, returnValueFirst);
            assertEquals(expectedValueLast, returnValueLast);
        }
    }
    
    @Nested
    @DisplayName("Test para el metodo append")
    class appendTest{
        @Test
        @DisplayName("Comprueba que con la lista vacia, al añadir por detras el primer nodo, el primero y el ultimo es el ultimo")
        public void append_EmptyList_FirstEqualsLast(){
            Object valor = new Object();
            node.append(valor);
            
            Object expectedValue1 = node.first();
            Object expectedValue2 = node.last();

            assertEquals(valor, expectedValue1);
            assertEquals(expectedValue1, expectedValue2);
        }

        @Test
        @DisplayName("Comprueba que si añadimos por detras dos nodos, el ultimo añadido sera el ultimo y el primero sera el primero")
        public void prepend_TwoNodes_LastIsFirst(){
            Object valor1 = new Object();
            node.append(valor1);
            Object valor2 = new Object();
            node.append(valor2);
            
            Object expectedValueFirst = valor1;
            Object returnValueFirst = node.first();
            Object expectedValueLast = valor2;
            Object returnValueLast = node.last();

            assertEquals(expectedValueFirst, returnValueFirst);
            assertEquals(expectedValueLast, returnValueLast);
        }
    }

    
    @Nested 
    @DisplayName("Test para el metodo deleteFirst")
    class deleteFirstTest{

         @Test
         @DisplayName("Comprueba que al borrar el primer elemento de una lista vacia lanza un error")
         public void deleteFirst_EmptyList_ThrowsError(){
            assertThrows(DoubleLinkedQueueException.class,()-> node.deleteFirst());
         }

        @Test 
        @DisplayName("Comprueba que al borrar el primer elemento de una lista, si es el unico el primero y el ultimo tiene que ser nulo y lanza una excepcion")
        public void deleteFirst_OneNode_ThrowsError(){
            Object valor = new Object();
            node.append(valor);
            node.deleteFirst();

            assertThrows(DoubleLinkedQueueException.class,()-> node.first());
            assertThrows(DoubleLinkedQueueException.class,()-> node.last());
        }
        

        @Test 
        @DisplayName("Comprueba que al borrar el primer elemento de una lista con dos elementos, el primer elemento de la lista pasa a ser el segundo y como solo hay un elemento tambien sera el ultimo")
        public void deleteFirst_TwoNodes_FirstIsNotNull(){
            Object valor1 = new Object();
            node.append(valor1);
            Object valor2 = new Object();
            node.append(valor2);
            node.deleteFirst();

            Object returnedValue = node.first();
            Object expectedValue = valor2;
            Object returnedValue2 = node.last();

            assertEquals(returnedValue, expectedValue);
            assertEquals(returnedValue2, expectedValue);
        }
    }

    
    @Nested 
    @DisplayName("Test para el metodo deleteLast")
    public class deleteLastTest{

        @Test
        @DisplayName("Comprueba que al borrar el ultimo elemento de una lista vacia lanza un error")
        public void deleteLast_EmptyList_ThrowsError(){
           assertThrows(DoubleLinkedQueueException.class,()-> node.deleteLast());
        }

        @Test 
        @DisplayName("Comprueba que al borrar el ultimo elemento de una lista, si es el unico el primero y el ultimo tiene que ser nulo y lanza una excepcion")
        public void deleteLast_OneNode_ThrowsError(){
            Object valor = new Object();
            node.append(valor);
            node.deleteLast();

            assertThrows(DoubleLinkedQueueException.class,()-> node.first());
            assertThrows(DoubleLinkedQueueException.class,()-> node.last());
        }

        @Test 
        @DisplayName("Comprueba que al borrar el ultimo elemento de una lista con dos elementos, el primer elemento de la lista seguira siendo el primero y como solo hay un elemento tambien sera el ultimo")
        public void deleteFirst_TwoNodes_FirstIsNotNull(){
            Object valor1 = new Object();
            node.append(valor1);
            Object valor2 = new Object();
            node.append(valor2);
            node.deleteLast();

            Object returnedValue = node.first();
            Object expectedValue = valor1;
            Object returnedValue2 = node.last();

            assertEquals(returnedValue, expectedValue);
            assertEquals(returnedValue2, expectedValue);
        }
    }
    
    @Nested 
    @DisplayName("Test para el metodo first")
    public class firstTest{
        @Test
        @DisplayName("Comprueba que first() lanza una excepcion si la lista esta vacia")
        public void first_EmptyList_ThrowsError(){
            assertThrows(DoubleLinkedQueueException.class, ()->node.first());
        }

        @Test
        @DisplayName("Comprueba que first() devuelve el primer elemento correctamente")
        public void first_TwoNodes_CheckFirst(){
            Object valor1 = new Object();
            Object valor2 = new Object();
            node.append(valor1);
            node.append(valor2);

            Object expectedValue = valor1;
            Object returnValue = node.first();

            assertEquals(expectedValue, returnValue);
        }
    }
    

    @Nested
    @DisplayName("Test para el metodo last")
    public class lastTest{
        @Test
        @DisplayName("Comprueba que last() lanza una excepcion si la lista esta vacia")
        public void last_EmptyList_ThrowsError(){
            assertThrows(DoubleLinkedQueueException.class,()-> node.last());
        }

        @Test
        @DisplayName("Comprueba que last() devuelve el ultimo elemento correctamente")
        public void last_TwoNodes_CheckLast(){
            Object valor1 = new Object();
            Object valor2 = new Object();
            node.append(valor1);
            node.append(valor2);

            Object expectedValue = valor2;
            Object returnValue = node.last();

            assertEquals(expectedValue, returnValue);
        }
    }
    
    @Nested
    @DisplayName("Test para el metodo size")
    public class sizeTest{

        @Test 
        @DisplayName("Comprueba que size() devuelve cero si la lista esta vacia")
        public void size_EmptyList_ReturnZero(){
            int expectedValue = 0;
            int returnValue = node.size();

            assertEquals(expectedValue, returnValue);
        }

        @Test 
        @DisplayName("Comprueba que size() devuelve uno si la lista tiene un elemento")
        public void size_OneNode_ReturnOne(){
            Object valor = new Object();
            node.append(valor);

            int expectedValue = 1;
            int returnedValue = node.size();

            assertEquals(returnedValue, expectedValue);
        }
    }

    @Nested 
    @DisplayName("Test para el metodo get")
    public class getTest{

        @Test
        @DisplayName("Comprueba que si intento devolver un objeto de la lista con una posicion menor a cero lanza un error")
        public void get_IndexLessZero_ThrowsError(){
            int index = -1;

            assertThrows(IndexOutOfBoundsException.class, ()-> node.get(index));
        }

        @Test
        @DisplayName("Comprueba que si intento devolver un objeto de la lista con una posicion mayor a la longitud de la lista lanza un error")
        public void get_IndexSize_ThrowsError(){
            int index = node.size() + 1;

            assertThrows(IndexOutOfBoundsException.class, ()-> node.get(index));
        }

        @Test 
        @DisplayName("Comprueba que me devuelve correctamente el nodo de la posicion que le paso")
        public void get_ValidIndex_CurrentNode(){
            Object elem1 = new Object();
            node.append(elem1);
            int index = 0;

            Object returnedValue = node.get(index);
            Object expectedValue = elem1;

            assertEquals(expectedValue, returnedValue);
        }

        @Test 
        @DisplayName("Comprueba que me devuelve correctamente el nodo de la posicion que le paso")
        public void get_ValidIndex_SecondNode(){
            Object elem1 = new Object();
            node.append(elem1);
            Object elem2 = new Object();
            node.append(elem2);
            int index = 1;

            Object returnedValue = node.get(index);
            Object expectedValue = elem2;

            assertEquals(expectedValue, returnedValue);
        }
    }

    @Nested 
    @DisplayName("Test para el metodo contains")
    public class containsTest{

        @Test 
        @DisplayName("Comprueba que contains() devuelve falso si la lista es vacia")
        public void contains_EmptyList_ReturnFalse(){
            Object valor = new Object();

            assertFalse(node.contains(valor));
        }

        @Test 
        @DisplayName("Comprueba que contains devuelve true con un unico elemento en lista")
        public void contains_OneNode_ReturnTrue(){
            Object valor = new Object();
            node.append(valor);

            assertTrue(node.contains(valor));
        }

        @Test 
        @DisplayName("Comprueba que contains devuelve true con un mas de un elemento en lista")
        public void contains_MoreThanOneNode_ReturnTrue(){
            Object valor1 = new Object();
            Object valor2 = new Object();
            Object valor3 = new Object();
            node.append(valor1);
            node.append(valor2);
            node.append(valor3);

            assertTrue(node.contains(valor3));
        }

    }

    @Nested 
    @DisplayName("Test para el metodo remove")
    public class removeTest{

        @Test 
        @DisplayName("Comprueba que borrar un elemento de una lista vacia no hace nada")
        public void remove_EmptyList_CheckEquals(){
            Object valor = new Object();
            node.remove(valor);

            int expectedValue = 0;
            int returnedValue = node.size();

            assertEquals(expectedValue, returnedValue);
        }

        @Test 
        @DisplayName("Comprueba que borrar un elemento que no existe no hace nada")
        public void remove_ObjetoInexistente_CheckEquals(){
            Object value = new Object();
            node.append(value);
            Object borrar = new Object();
            node.remove(borrar);

            int expectedValue = 1;
            int returnedValue = node.size();

            assertEquals(expectedValue, returnedValue);
        }

        @Test 
        @DisplayName("Comprueba que borra un elemento correctamente si el previo es nulo")
        public void remove_PrevioNulo_Check(){
            Object value1 = new Object();
            node.append(value1);
            Object value2 = new Object();
            node.append(value2);
            node.remove(value1);

            Object expectedValue = value2;
            Object returnedValue = node.first();

            assertEquals(expectedValue, returnedValue);
        }

        @Test 
        @DisplayName("Comprueba que borra un elemento correctamente si el previo no es nulo")
        public void remove_PrevioNoNulo_Check(){
            Object value1 = new Object();
            node.append(value1);
            Object value2 = new Object();
            node.append(value2);
            node.remove(value2);

            Object expectedValue = value1;
            Object returnedValue = node.last();

            assertEquals(expectedValue, returnedValue);
        }

        @Test 
        @DisplayName("Comprueba que borra un elemento correctamente si el siguiente es nulo")
        public void remove_LastNull_Check(){
            Object value1 = new Object();
            node.append(value1);
            Object value2 = new Object();
            node.append(value2);
            Object value3 = new Object();
            node.append(value3);
            node.remove(value3);

            Object expectedValue = value2;
            Object returnedValue = node.last();

            assertEquals(expectedValue, returnedValue);
        }

        @Test 
        @DisplayName("Comprueba que borra un elemento correctamente si el siguiente no es nulo")
        public void remove_LastNotNull_Check(){
            Object value1 = new Object();
            node.append(value1);
            Object value2 = new Object();
            node.append(value2);
            Object value3 = new Object();
            node.append(value3);
            node.remove(value2);

            int expectedValue = 2;
            int returnedValue = node.size();

            assertEquals(expectedValue, returnedValue);
        }
    }

    @Nested
    @DisplayName("Test para el metodo sort")
    public class sortTest{

        @Test 
        @DisplayName("Comprueba que ordena de forma adecuada una lista vacia")
        public void sort_EmptyList_Check(){
            DoubleLinkedList<Integer> expectedValue = new DoubleLinkedList<>();
            DoubleLinkedList<Integer> returnValue = new DoubleLinkedList<>();

            returnValue.sort(Comparator.naturalOrder());
            boolean sol = true; 
            for(int i=0;i<expectedValue.size();i++){
                if(expectedValue.get(i)!=returnValue.get(i)){
                    sol = false;
                }
            }
        
            assertTrue(sol);
        }

        @Test 
        @DisplayName("Comprueba que ordena de forma adecuada una lista de un solo elemento")
        public void sort_OneNode_Check(){
            DoubleLinkedList<Integer> expectedValue = new DoubleLinkedList<>();
            DoubleLinkedList<Integer> returnValue = new DoubleLinkedList<>();

            expectedValue.append(5);
            returnValue.prepend(5);
            returnValue.sort(Comparator.naturalOrder());
            boolean sol = true; 
            for(int i=0;i<expectedValue.size();i++){
                if(expectedValue.get(i)!=returnValue.get(i)){
                    sol = false;
                }
            }
        
            assertTrue(sol);
        }


        @Test 
        @DisplayName("Comprueba que ordena de forma adecuada una lista ya ordenada")
        public void sort_List_Check(){
            DoubleLinkedList<Integer> expectedValue = new DoubleLinkedList<>();
            DoubleLinkedList<Integer> returnValue = new DoubleLinkedList<>();

            expectedValue.append(1);
            expectedValue.append(2);
            expectedValue.append(3);
            expectedValue.append(4);
            returnValue.append(1);
            returnValue.append(2);
            returnValue.append(3);
            returnValue.append(4);
            returnValue.sort(Comparator.naturalOrder());
            boolean sol = true; 
            for(int i=0;i<expectedValue.size();i++){
                if(expectedValue.get(i)!=returnValue.get(i)){
                    sol = false;
                }
            }
        
            assertTrue(sol);
        }

        @Test 
        @DisplayName("Comprueba que ordena de forma adecuada una lista desordenada")
        public void sort_UnsortereddList_Check(){
            DoubleLinkedList<Integer> expectedValue = new DoubleLinkedList<>();
            DoubleLinkedList<Integer> returnValue = new DoubleLinkedList<>();

            expectedValue.append(1);
            expectedValue.append(2);
            expectedValue.append(3);
            expectedValue.append(4);
            returnValue.append(3);
            returnValue.append(1);
            returnValue.append(4);
            returnValue.append(2);
            returnValue.sort(Comparator.naturalOrder());
            boolean sol = true; 
            for(int i=0;i<expectedValue.size();i++){
                if(expectedValue.get(i)!=returnValue.get(i)){
                    sol = false;
                }
            }
        
            assertTrue(sol);
        }

    }

}