//Realizado por Javier Torrecilla Reyes y Sandra Vázquez Pérez

package queue;

public class DoubleLinkedQueueException extends RuntimeException {
    public DoubleLinkedQueueException(String message) {
        super(message);
    }
}
