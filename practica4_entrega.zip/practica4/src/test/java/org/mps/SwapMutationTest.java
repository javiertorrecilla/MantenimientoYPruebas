//practica realizada por Javier Torrecilla Reyes y Sandra Vázquez Pérez

package org.mps;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.mps.mutation.SwapMutation;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.*;

public class SwapMutationTest {
    
    private SwapMutation swapMutation;

    @BeforeEach
    public void init(){
        swapMutation = new SwapMutation();
    }

    @Test 
    @DisplayName("Test que comprueba que si se le pasa el parametro a nulo lanza una excepcion")
    public void mutate_individualNull_throwsError(){
        int[] individual = null;

        assertThrows(EvolutionaryAlgorithmException.class, ()->swapMutation.mutate(individual));
    }

    @Test 
    @DisplayName("Test que comprueba que si se le pasa el parametro individual con longitud cero lanza una excepcion")
    public void mutate_individualLengthZero_throwsError(){
        int[] individual = new int[0];

        assertThrows(EvolutionaryAlgorithmException.class, ()->swapMutation.mutate(individual));
    }

    @Test 
    @DisplayName("Test que comprueba que si se le pasa un unico valor dentro del parametro se intercambia con él mismo y se queda como está")
    public void mutate_individualLengthOne_assertEquals() throws EvolutionaryAlgorithmException{
        int[] individual = new int[1];
        individual[0] = 2;

        int[] returnedValue = swapMutation.mutate(individual);
        
        assertEquals(individual.length, returnedValue.length);
        assertEquals(individual[0], returnedValue[0]);
    }

    @Test 
    @DisplayName("Test que comprueba que si se le pasan cuatro valores dentro del parametro los tamaños los arrays son iguales pero no iguales")
    public void mutate_individualLengthFour_assertEquals() throws EvolutionaryAlgorithmException{
        int[] individual = {1,2,3,4};

        int[] returnedValue = swapMutation.mutate(individual);

        assertEquals(returnedValue.length, individual.length);
        //he eliminado comprobar que los arrays al hacer el mutate sean distintos,
        //ya que se puede dar el caso de que al seleccionar el random se seleccione el mismo
        //y al hacer el intercambio los arrays se queden igual
    }

}
