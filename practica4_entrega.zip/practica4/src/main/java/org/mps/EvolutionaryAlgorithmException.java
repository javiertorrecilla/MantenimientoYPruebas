//practica realizada por Javier Torrecilla Reyes y Sandra Vázquez Pérez

package org.mps;

public class EvolutionaryAlgorithmException  extends Exception{
	public EvolutionaryAlgorithmException() {
		super();
	}
	public EvolutionaryAlgorithmException(String mensaje) {
		super(mensaje);
	}
}
